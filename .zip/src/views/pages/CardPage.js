import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import CardDetails from './CardDetails'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Divider from '@mui/material/Divider';
import Loader from 'react-spinner-loader';
import { useLocation, useNavigate } from 'react-router-dom';
import { Modal, ModalHeader, ModalBody } from 'reactstrap';
import { CSSTransition } from 'react-transition-group';
import {
  Container,
  Row,
  Col,
  Button
} from "reactstrap";
import Select from 'react-select'
import axios from 'axios';
import { createGenerateClassName, StylesProvider } from '@material-ui/core/styles';
export default function CardPage() {
  const [loading, setloading] = useState(true);
  const [showModal, setshowModal] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const [isPopupOpen, setPopupOpen] = useState(false);
  const togglePopup = () => setPopupOpen(!isPopupOpen);
  const generateClassName = createGenerateClassName({
    productionPrefix: 'c',
    disableGlobal: true
  });
  const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_KEY);
  const emailForPay = localStorage.getItem('emailForPayment');
  useEffect(() => {
    setloading(false)
    // fetchData()
  }, []);
  const toggleModal = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth', // You can use 'auto' instead of 'smooth' for an instant scroll
    });
    setPopupOpen(true);
    setTimeout(() => {
      // Close the wait popup after the process is complete
      togglePopup();
    }, 10000);
  }
  const handleModalClick = () => {
    setshowModal(false)
    navigate(`/admin/user-profile`);
  }
  const imageStyle = {
    width: '3rem',
    height: '3rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    margin: 'auto', // Center horizontally
    marginBottom: '10px',
  };
  const AnimationPopup = ({ isOpen, toggle }) => {
    return (
      <CSSTransition
        in={isOpen}
        timeout={300} // Set the duration of the animation
        classNames="nice-animation"
        unmountOnExit
      >
        <Modal isOpen={isOpen} toggle={toggle}>
          <ModalBody classsName="contentCenter">
            <div className='successMessageContainer'>
              <div className='successPaymentIcon'></div>
              <h2 className="successText">SUCCESS </h2>
              <h5>Thanks for Your Subscription payment</h5>
              <h5></h5>
              <Button
                // color="primary"
                className=" outline text-white bg-green buttonCss"
                disabled={false}
                onClick={() => handleModalClick()}
                size="lg"
              >
                Continue
              </Button>
            </div>

          </ModalBody>
        </Modal>

      </CSSTransition>
    );
  };
  return (
    <>
      {loading ?
        <div
          className="header pb-8 pt-5 pt-lg-6 d-flex align-items-center"
        >
          <Container className="mt--10" fluid>
            <Loader show={loading} type="box" spinnerStyle={{
              primary: '#46B597',
              secondary: '#2D866D'
            }} />

          </Container>
        </div> :
        <div className="header pb-8 pt-5 pt-md-5">
          {isPopupOpen ?
            <AnimationPopup isOpen={isPopupOpen} toggle={togglePopup} />
            : null}
          <Container className="align-items-center" fluid>
            <Row>
              <Col lg="8" xl="8">
                <h1 className="display-3 text-gradient-darker">Payment Details</h1>
              </Col>

            </Row>
          </Container>
          <StylesProvider generateClassName={generateClassName}>
            <div className="paymentContainer">
              <Card className='cardForPayment'>
                <CardContent>
                  <div className="headingforTextContent">
                    Subscription Payment

                  </div>
                  <div className="costForCousreContainer">
                    <div className="costForCourse">
                      {location.state.subscriptionAmount}
                    </div>
                    {location.state.planName === "Certificate Member" ? null : <div className="permonthConatiner">per {location.state.frequency}</div>}
                  </div>
                  <div className="subcriptionContainer">
                    <div className="subcriptionText">
                      Subscription Fees
                    </div>
                    <div classsName="currencyAmount">{location.state.subscriptionAmount}</div>
                  </div>
                  <div className="subcriptionContainer">
                    <div className="subcriptionText">
                      Discount Fees
                    </div>
                    <div classsName="currencyAmount">{location.state.discountForCourse}</div>
                  </div>
                  <div className="subcriptionContainer">
                    <div className="subcriptionText">
                      Fees to pay
                    </div>
                    <div classsName="currencyAmount">{location.state.amountToPay}</div>
                  </div>
                  <hr className="horizontalLine" />
                  <div className="subcriptionContainer">
                    <div className="subcriptionText">
                      Subtotal
                    </div>
                    <div classsName="currencyAmount">{location.state.amountToPay}</div>
                  </div>
                </CardContent>
              </Card>
              <Divider orientation="vertical" flexItem className="separator" />

              {<Elements stripe={stripePromise}>
                <CardDetails showCerificate={location.state.coursesSelected} currency={location.state.currency} costToPass={location.state.cost} planCost={location.state.amountToPay} certificateSelected={location.state.certificateSelected} certificateDetails={location.state.categoriesResponse} openModelFn={toggleModal} frequencyPlan={location.state.frequency} planForPay={location.state.planName} />
              </Elements>}
            </div>
          </StylesProvider>
        </div>}
    </>

  );
}
