import React, { useState, useEffect } from 'react';
import { Col, Card, CardBody, FormGroup, Input,Container, InputGroupAddon, InputGroupText, InputGroup, Label, Row, Button } from 'reactstrap';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { GoogleLogin } from '@react-oauth/google';
import { jwtDecode } from 'jwt-decode';
import { useDispatch } from 'react-redux';
import { ACCOUNT_INITIALIZE } from '../../../store/actions';
import configData from '../../../config';
import { useNavigate } from "react-router-dom"
import { ThreeDots } from 'react-loader-spinner'

const GoogleLoginButton = () => {
  const navigate = useNavigate();
  const dispatcher = useDispatch();
  const responseGoogle = async (response) => {
    try {
      console.log('Response:', response);
      // Send the response to your Flask backend for authentication
      const backendResponse = await axios.post('https://studybot-ehasl4rfha-uc.a.run.app/api/VerifyGoogle', {
        tokenId: response.credential,
      });
      console.log('Backend Response:', backendResponse.data);
      localStorage.setItem('emailForPayment', backendResponse.data.user.username)
      //history.push('/dashboard');
      if (backendResponse.data.success) {
        dispatcher({
          type: ACCOUNT_INITIALIZE,
          payload: { isLoggedIn: true, user: backendResponse.data.user, token: backendResponse.data.token, isGoogleLogin: true },
        });
        navigate('/admin/index');
      }
    } catch (error) {
      console.error('Error during Google login:', error);
    }
  };

  return (
    <GoogleLogin
      clientId="678138449376-njuhfuaoh2rff0g9djjlgu754p8fqn03.apps.googleusercontent.com"
      buttonText="Login with Google"
      onSuccess={responseGoogle}
      onFailure={responseGoogle}
      cookiePolicy={'single_host_origin'}
      uxMode="popup" // or "popup"
      prompt="select_account"
    />
  );
};

const Login = () => {
  const navigate = useNavigate();
  const dispatcher = useDispatch();
  const [isChecked, setIsChecked] = useState(false);
  const [errormsgFromLogin, seterrormsgFromLogin] = useState('');
  const [showPassword, setShowPassword] = useState(false)
  const [showLoader, setshowLoader] = useState(false)
  useEffect(() => {
    const storedEmail = localStorage.getItem('rememberedEmail');
    if (storedEmail) {
      setIsChecked(true);
    }
  }, []);
  const handleCheckboxChange = () => {
    setIsChecked(!isChecked);
    // Clear the stored email if "Remember Me" is unchecked
    if (!isChecked) {
      localStorage.removeItem('rememberedEmail');
    }
  };
  const handleShowPassword = () => {
    setShowPassword(!showPassword)
  }


  const showPasswordVal = !showPassword ? 'password' : 'text';
  return (
    <>
      <Container className="mt--10" fluid style={{marginTop:'60px',marginLeft:'235px'}}>  
      <Col lg="9" md="9">
        <Card className="shadow border-0 boxshadowEffect">
          <CardBody className="px-lg- py-lg-5">
            <div className="text-center signinText">Login to your account</div>
            <Formik
              initialValues={{
                password: '',
                email: localStorage.getItem('rememberedEmail') || '',
              }}
              validationSchema={Yup.object().shape({
                email: Yup.string().email('Must be a valid email').max(255).required('Email is required'),
                password: Yup.string().max(255).required('Password is required'),
              })}
              onSubmit={async (values, { setErrors, setStatus, setFieldValue }) => {
                if (isChecked) {
                  localStorage.setItem('rememberedEmail', values.email);
                } else {
                  localStorage.removeItem('rememberedEmail'); // Remove from localStorage if not checked
                }
                try {
                  setshowLoader(true)
                  const response = await axios.post(configData.API_SERVER + 'users/login', {
                    password: values.password,
                    email: values.email,
                  });

                  if (response.data.success) {
                    console.log(response.data);
                    localStorage.setItem('emailForPayment', response.data.user.email)
                    localStorage.setItem('isAdmin', response.data.is_admin)
                    seterrormsgFromLogin('');
                    dispatcher({
                      type: ACCOUNT_INITIALIZE,
                      payload: { isLoggedIn: true, user: response.data.user, token: response.data.token, isGoogleLogin: false, isAdmin: response.data.is_admin },
                    });

                    navigate('/admin/index');
                  } else {
                    setshowLoader(false)
                    setStatus({ success: false });
                    setErrors({ submit: response.data.msg });
                    seterrormsgFromLogin(response.data.msg);
                  }
                } catch (error) {
                  setshowLoader(false)
                  setStatus({ success: false });
                  setErrors({ submit: error.response.data.msg });
                  seterrormsgFromLogin(error.response.data.msg);
                }
              }}
            >
              {({ errors, handleBlur, handleChange, touched, values }) => (
                <Form>
                  <FormGroup className="groupForEmail">
                    <Label for="email">Email</Label>
                    <InputGroup className="input-group-alternative">
                      <InputGroupAddon addonType="prepend">
                        <InputGroupText>
                          <i className="ni ni-email-83" />
                        </InputGroupText>
                      </InputGroupAddon>
                      <Input
                        type="email"
                        value={values.email}
                        placeholder="Email"
                        name="email"
                        onBlur={handleBlur}
                        onChange={handleChange}
                        label="Email Address"
                      />

                    </InputGroup>
                    {touched.email && errors.email && (
                      <span style={{ color: 'red' }}>{errors.email} </span>
                    )}
                  </FormGroup>

                  <FormGroup className="groupForPassword">
                    <div className="passwordContainerDiv">
                      <Label for="password">Password</Label>
                      <a
                        href="javascript:void(0)"
                        className="text-light linkLogincss"
                        onClick={() => navigate('/auth/forgot-password')}
                      >
                        <small>Forgot password?</small>
                      </a>
                    </div>
                    <InputGroup className="input-group-alternative">
                      <InputGroupAddon addonType="prepend">
                        <InputGroupText>
                          <i className="ni ni-lock-circle-open" />
                        </InputGroupText>
                      </InputGroupAddon>
                      <Input
                        placeholder="Password"
                        type={showPasswordVal}
                        value={values.password}
                        name="password"
                        onBlur={handleBlur}
                        onChange={handleChange}
                            autocomplete="off"
                      />
                      <InputGroupAddon addonType="append">
                        <InputGroupText>
                          <div className='passwordIcon' onClick={handleShowPassword}></div>
                        </InputGroupText>
                      </InputGroupAddon>
                    </InputGroup>
                    {touched.password && errors.password && (
                      <span style={{ color: 'red' }}>{errors.password} </span>
                    )}
                  </FormGroup>

                  <div>
                    <Label className="checkbox-container mb-2">
                      <Input
                        type="checkbox"
                        checked={isChecked}
                        onChange={handleCheckboxChange}
                        className="mr-2 custom-checkbox-input-login"
                      />
                      <span className="checkmark"></span>
                      <span className="text-muted">Remember me</span>
                    </Label>
                  </div>

                  <div className="text-center errorMessageForLogin">{errormsgFromLogin}</div>

                  <div className="text-center">
                    <Button className="my-4 classForButtonLogin" color="primary" type="submit">
                      {!showLoader ? <span>Sign in</span> :
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>

                          <ThreeDots
                            visible={true}
                            height="20"
                            width="40"
                            color="#ffffff"
                            radius="9"
                            ariaLabel="three-dots-loading"
                            wrapperStyle={{}}
                            wrapperClass=""
                          />
                        </div>
                      }
                    </Button>
                  </div>
                </Form>
              )}
            </Formik>

            <Row className="mt-3">
              <Col className="text-left createNewAccountContent" xs="12">
                Don't have an account?
                <a
                  href="javascript:void(0)"
                  className="text-light linkCreateNewAccountcss"
                  onClick={() => navigate('/auth/register')}
                >
                  <small>Create new account</small>
                </a>
              </Col>
            </Row>

            <div className="signInGoogleLogin">
              <div className="px-lg-7">
                <GoogleLoginButton />
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>
      </Container>
    </>
  );
};

export default Login;
