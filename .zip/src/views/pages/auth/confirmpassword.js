import React, { useState, useEffect } from 'react';
import { Col, Card, CardBody, FormGroup, Input, InputGroupAddon, InputGroupText, InputGroup, Label, Row, Button } from 'reactstrap';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import { useDispatch } from 'react-redux';
import { useNavigate } from "react-router-dom"


const FormSchema = Yup.object().shape({
  pass: Yup
    .string()
    .min(8, 'Password must be 8 characters long')
    .matches(/[0-9]/, 'Password requires a number')
    .matches(/[a-z]/, 'Password requires a lowercase letter')
    .matches(/[A-Z]/, 'Password requires an uppercase letter')
    .matches(/[^\w]/, 'Password requires a symbol'),
  confirm: Yup
    .string()
    .oneOf([Yup.ref('pass'), null], 'Must match "password" field value'),
});

const Forgetpass = () => {
  const navigate = useNavigate();
  const dispatcher = useDispatch();
  const [isChecked, setIsChecked] = useState(false);
  const [errormsgFromLogin, seterrormsgFromLogin] = useState('');
  const [showPassword, setShowPassword] = useState(false)
  const [showLoader, setshowLoader] = useState(false)
  useEffect(() => {
    const storedEmail = localStorage.getItem('rememberedEmail');
    if (storedEmail) {
      setIsChecked(true);
    }
  }, []);


  const showPasswordVal = !showPassword ? 'password' : 'text';
  return (
    <>
      <Col lg="8" md="9">
        <Card className="shadow border-0 boxshadowEffect">
          <CardBody className="px-lg-5 py-lg-5">
            <div className="text-center  mb-4 signinText">Recover Your Password</div>
            <Formik
              initialValues={{
                pass:'',
                confirm: '',
              }}
              validationSchema={FormSchema}
              onSubmit={(values) => {
                navigate('/auth/login')
              }}
            >
              {({ errors, handleBlur, handleChange, touched, values }) => (
                <Form>
                  <FormGroup className="groupForEmail">
                    <Label for="email">New Password</Label>
                    <InputGroup className="input-group-alternative marginBottomForNewPassword">
                      <InputGroupAddon addonType="prepend">
                        <InputGroupText>
                          <i className="ni ni-lock-circle-open" />
                        </InputGroupText>
                      </InputGroupAddon>
                      <Input
                        type="password"
                        value={values.password}
                        placeholder="New Password"
                        name="pass"
                        label="New Password"
                        onBlur={handleBlur}
                        onChange={handleChange}
                      />

                    </InputGroup>
                    <Label for="email">Confirm New Password</Label>
                    <InputGroup className="input-group-alternative">
                      <InputGroupAddon addonType="prepend">
                        <InputGroupText>
                          <i className="ni ni-lock-circle-open" />
                        </InputGroupText>
                      </InputGroupAddon>
                      <Input
                        type="password"
                        value={values.passwordConfirmation}
                        placeholder="Confirm New Password"
                        name="confirm"
                        label="Confirm New Password"
                        onBlur={handleBlur}
                        onChange={handleChange}
                      />

                    </InputGroup>
                    {errors.pass && (
                      <span style={{ color: 'red' }}>{errors.pass} </span>
                    )}
                     {errors.confirm && <span style={{ color: 'red' }}>{errors.confirm}</span>}
                  </FormGroup>
                  <div className="text-center errorMessageForLogin">{errormsgFromLogin}</div>
                  <div className="text-center">
                    <Button className="my-4 classForButtonLogin" color="primary" type="submit" disabled={errors.pass || errors.confirm ||values.pass=="" ||values.confirm==""}>
                      <span>Save</span>

                    </Button>
                  </div>
                </Form>
              )}
            </Formik>

            <Row className="mt-3">
              <Col className="text-left createNewAccountContent" xs="12">
                Don't want to reset?
                <a
                  href="javascript:void(0)"
                  className="text-light linkCreateNewAccountcss"
                  onClick={() => navigate('/auth/login')}
                >
                  <small>Go back to login</small>
                </a>
              </Col>
            </Row>

          </CardBody>
        </Card>
      </Col>
    </>
  );
};

export default Forgetpass;
