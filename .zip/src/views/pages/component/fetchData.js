
import { useDispatch } from 'react-redux';
import { LOGOUT } from 'store/actions';
import axios from 'axios';

// Custom hook to handle data fetching
const useFetchData = () => {
  const dispatch = useDispatch();

  const fetchData = async (method, url, data, token, onSuccess, onError, onLogout) => {
    try {
      const header = {
        headers: { 'Authorization': 'Bearer ' + token }
      };
      let response;

      switch (method.toLowerCase()) {
        case 'get':
          response = await axios.get(url, header);
          break;
        case 'post':
          response = await axios.post(url, data, header);
          break;
        case 'put':
          response = await axios.put(url, data, header);
          break;
        case 'delete':
          response = await axios.delete(url, header);
          break;
        // Add more cases for other HTTP methods as needed
  
        default:
          console.error(`Error: Unsupported HTTP method - ${method}`);
          return;
      }

      if (response && response.data) {
        onSuccess(response.data);
      } else {
        console.error('Error: Empty or invalid response');
      }
    } catch (error) {
      if (error.response && error.response.status === 400) {
        dispatch({
          type: LOGOUT
        });
      }

      onError(error);
    }
  };

  return { fetchData };
};

export default useFetchData;

