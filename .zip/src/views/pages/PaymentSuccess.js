import React from 'react';


export default function PaymentSuccess() {
  return (
    <div>Your payment has been done successfully</div>
  );
}
