

import React, { useEffect, useState } from 'react';
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  FormGroup,
  Input,
  InputGroup,
  Container,
  Row,
  Col,
  Table
} from 'reactstrap';
import configData from '../../../config';
import { useSelector } from 'react-redux';
import { ThreeDots } from 'react-loader-spinner'
import useFetchData from '../component/fetchData';
import { useNavigate } from "react-router-dom"
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { useLocation } from 'react-router-dom';
import Select from 'react-select'
const CertificateDetailsModule = () => {
  const { fetchData } = useFetchData();
  const account = useSelector((state) => state.account);
  const navigate = useNavigate();
  const [isPopupOpen, setPopupOpen] = useState(false);
  const togglePopup = () => setPopupOpen(!isPopupOpen);
  const isPremiumUser = localStorage.getItem('isPremiumUser');
  const [enableUpdateButton, setenableUpdateButton] = useState(false);
  const [isPopupOpenForSuccess, setPopupOpenForSuccess] = useState(false);
  const togglePopupForSuccess = () => setPopupOpenForSuccess(!isPopupOpenForSuccess);
  const [loading, setloading] = useState(true);
  const [paymentDetails, setPaymentDetails] = useState([]);
  const location = useLocation();
  const [dropdownVal, setDropdownVal] = useState({ label: 'Select Certificate', value: 'Select Certificate' })
  const [initialValues, setInitialValues] = useState({

  });
  const categories = useSelector((state) => state.domainCeretifctaes);
  console.log(categories,'wewewewCatretwe')
  const [coursesForDropdown, setCoursesForDropdown] = useState([])
  const [modulesData, setModulesData] = useState({
    modules: ["Module 1", "Module 2", "Module 3"],
    inputFields: [{
      fieldValue: "10",
      fieldLabel: "Total Question",

    },
    {
      fieldValue: "50",
      fieldLabel: "Passing Mark",

    }, {
      fieldValue: "35",
      fieldLabel: "Total Time",

    }, {
      fieldValue: "url.com",
      fieldLabel: "Detailed Url",

    }]

  })
  const handleSelect = (e) => {
    setDropdownVal({ label: e.value, value: e.value })
  }
  const toggleModalForSuccess = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
    setPopupOpenForSuccess(true);
    setTimeout(() => {
      // Close the wait popup after the process is complete
      //setPopupOpenForSuccess(false);
    }, 10000);
  }

  const handleModalClickForSuccess = () => {
    setPopupOpenForSuccess(false)
  }
  const handleModalClick = () => {
    setPopupOpen(false)
    // navigate(`/admin/user-profile`);
  }
  const handleModuleClick = () => {
    navigate(`/admin/user-modules-details`)
  }


  useEffect(() => {
    const uniqueCourseName = [...new Set(categories.certificates.response.map(item => item.courseName))];
    const uniqueCourseToPass = uniqueCourseName.map(item => {
      let obj = {};
      obj.label = item;
      obj.value = item;
      return obj
    })
   // setDropdownVal(uniqueCourseToPass)
    setCoursesForDropdown(uniqueCourseToPass)
    setloading(false)
  }, [account.token]);

const handleUpdateButton =()=>{
  
}
  const handleChange = (event, item) => {
    console.log(event.target.value, item, 'weweweinput')
    const moduleDetailsData = modulesData.inputFields.map(itemTemp => {
      if (itemTemp.fieldLabel === item) {
        itemTemp.fieldValue = event.target.value
      }
      return itemTemp
    })
    const deatilsToPass = { modules: modulesData.modules, inputFields: moduleDetailsData }
    setModulesData(deatilsToPass)
  }
  return (
    <>
      <div className="header pb-8 pt-5 d-flex align-items-center">
        <Container className="mt--10" fluid>


          {
            loading ? <div
              className="header pb-8 d-flex align-items-center"
            >
              <Container className="mt--10" fluid>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '40vh' }}>

                  <ThreeDots
                    visible={true}
                    height="80"
                    width="80"
                    color="#172b4d"
                    radius="9"
                    ariaLabel="three-dots-loading"
                    wrapperStyle={{}}
                    wrapperClass=""
                  />
                </div>

              </Container>
            </div> :
              <>
                <Row className="mb-3">
                  <Col className="order-xl-2 mb-5 mb-xl-0" xl="4">
                  </Col>
                  <Col className="order-xl-2 mb-5 mb-xl-0 " xl="4">
                    <div className="headingforTextContent headingForCertifcateLabel">
                      Select Certificate
                    </div>
                    <Select options={coursesForDropdown} onChange={(e) => handleSelect(e)} value={dropdownVal} />
                  </Col>
                  <Col className="order-xl-2 mb-5 mb-xl-0" xl="4">

                  </Col>
                </Row>
                <Row>

                  {dropdownVal.value !== "Select Certificate" ? <Col className="order-xl-2 mb-5 mb-xl-0" xl="5">
                    <Card className="card-profile shadow">
                      <CardHeader className="text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">

                      </CardHeader>
                      <CardBody>
                        <Row>
                          {
                            modulesData.modules.map(item => {
                              return (
                                <Col lg="12" key={item}>
                                <div className='d-flex my-2 cursorCss'>
                                    <div onClick={handleModuleClick}>
                                      {item}
                                    </div>
                                    <ArrowForwardIosIcon />
                                  </div>

                                </Col>
                              )
                            })
                          }
                        </Row>
                      </CardBody>
                    </Card>
                  </Col> : null}
                  {dropdownVal.value !== "Select Certificate" ? <Col className="order-xl-1" xl="7">
                    <Card className="bg-gradient-default shadow">
                      <CardHeader className="bg-gradient-default  border-0">
                        <Row className="align-items-center">
                          <Col xs="8">
                            <h3 className="mb-0 text-white">Details</h3>
                          </Col>
                        </Row>
                      </CardHeader>
                      <CardBody>
                        <div className="pl-lg-4">

                          <Row>
                            {
                              modulesData.inputFields.map(item => {
                                return (
                                  <Col lg="6">
                                    <FormGroup className="mb-3" disabled={!enableUpdateButton}>
                                      <label
                                        className="form-control-label text-white"
                                        htmlFor=""

                                      >
                                        {item.fieldLabel}
                                      </label>

                                      <InputGroup className="input-group-alternative">

                                        <Input
                                          type="text"
                                          onChange={(e) => handleChange(e, item.fieldLabel)}
                                          name={item.fieldLabel}         // Update to first_name
                                          value={item.fieldValue}
                                          placeholder={item.fieldLabel}

                                        />

                                      </InputGroup>
                                    </FormGroup>


                                  </Col>
                                )
                              })
                            }
                          </Row>
                          <Row>
                            <Col xs="4">
                              <Button
                                color="primary"
                                // href="#pablo"
                                onClick={() => handleUpdateButton()}
                                size="lg"
                              >
                                Update
                              </Button>
                            </Col>
                          </Row>

                        </div>
                        <hr className="my-4" />
                        {/* Address */}


                      </CardBody>
                    </Card>
                  </Col> : null}
                </Row>

              </>
          }
        </Container>
      </div >
    </>
  );
};

export default CertificateDetailsModule;
