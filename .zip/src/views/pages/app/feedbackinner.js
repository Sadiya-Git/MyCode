import React, { useState } from 'react';

const FeedbackItem = ({ isCorrect, optionId, optionText, feedback, correctOptions }) => {
    const [showExplanation, setShowExplanation] = useState(false);

    const handleToggleExplanation = () => {
        setShowExplanation(!showExplanation);
    };

    return (
        <div className={`feedback-item ${showExplanation ? 'show-explanation' : ''}`} style={{ fontWeight: 'bolder' }}>
            <div>
                {isCorrect ? (
                    <>
                        <span className="text-success">
                            {optionId} : {optionText}
                        </span>
                        &nbsp; <i className="fas fa-check-circle text-success"></i>
                    </>
                ) : (
                    <>
                        <span className="text-danger">
                            {optionId} : {optionText}
                        </span>
                        &nbsp; <i className="fas fa-times-circle text-danger"></i>
                    </>
                )}
            </div>

            {!isCorrect && (
          <div className="correct-answer">
            <br/>
            {correctOptions.map((correctOption) => (
              <span key={correctOption.option_id} className="text-success">
                {correctOption.option_id} : {correctOption.text}{' '}
                <i className="fas fa-check-circle text-success"></i>
              </span>
            ))}
          </div>
        )}
           <br/>
            <div className="toggle-explanation text-default" onClick={handleToggleExplanation}>
                {showExplanation ? 'Hide Explanation' : 'Show Explanation'}
            </div>
            {showExplanation && feedback && (
                <div className="feedback-box">
                    <div className="feedback-content text-white" style={{ fontWeight: 'bolder' }}>
                        <p>{feedback}</p>
                    </div>
                </div>
               
            )}
        </div>
    );
};


export default FeedbackItem;
