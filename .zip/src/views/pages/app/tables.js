import Chart from "chart.js";
import {
  Card,
  CardHeader,
  Progress,
  Table,
  Container,
  Row,
  Col,
  Media,
} from "reactstrap";
import {
  chartOptions,
  parseOptions,
} from "variables/charts.js";
import { useSelector } from 'react-redux';
import Pagination from 'react-mui-pagination';
import { MuiThemeProvider, createTheme } from '@material-ui/core/styles';
import { useEffect, useState } from "react";
import configData from '../../../config';
import { ThreeDots } from 'react-loader-spinner'
import useFetchData from '../component/fetchData';
import FilterComponent from './filterComponent'
import Fab from '@material-ui/core/Fab';
const theme = createTheme({
  palette: {
    primary: {
      main: '#32325D'
    }
  }
});
const Index = (props) => {
  const itemsPerPage = 9;
  const [page, setPage] = useState(1);
  const [noOfPages, setnoOfPages] = useState('');
  const [tableData, settableData] = useState([]);
  const [tableDataRef, settableDataRef] = useState([]);
  const [loading, setloading] = useState(true);
  const account = useSelector((state) => state.account);
  const url = configData.API_SERVER + 'getUserScores';
  const data = {
    courseId:"",
    startDate:"",
    endDate:"",
    coursePercentage:""
  }, method = 'put';
  const { fetchData } = useFetchData();
  const [filterToggle, setFilterToggle] = useState(false)
  if (window.Chart) {
    parseOptions(Chart, chartOptions());
  }
  const applyFilterChange=(paramObj)=>{
    fetchData(method, url, paramObj, account.token,
      (response) => {
        setloading(false)
        console.log(response,'ererer')
        settableData(response.scores);
      },
      (error) => {
        console.error("Error occurred:", error);
      }
    );
  }
  const handleChange = (event, value) => {
    setPage(value);
  };
  useEffect(() => {
    fetchData(method, url, data, account.token,
      (response) => {
        setloading(false)
        console.log(response,'ererer')
        settableData(response.scores);
        settableDataRef(response.scores)
      },
      (error) => {
        console.error("Error occurred:", error);
      }
    );
    // handleDynamicContent()
  }, [account.token])

  // const handleFilterClick=()=>{
  //   setFilterToggle(!filterToggle)
  // }

  return (
    <>
      {loading ? <div
        className="header pb-8 pt-5 pt-lg-6 d-flex align-items-center"

      >
        <Container className="mt--10" fluid>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '70vh' }}>

            <ThreeDots
              visible={true}
              height="80"
              width="80"
              color="#172b4d"
              radius="9"
              ariaLabel="three-dots-loading"
              wrapperStyle={{}}
              wrapperClass=""
            />
          </div>

          {/* <Loader type="Circles" color="Red" height={180} width={180} /> */}
        </Container>
      </div> :
        <div className="header  pb-6 pt-5 pt-md-6">
          {/* Page content */}
          <Container fluid>
            {/* <Row>
         
          </Row> */}
            <br />
            <Row>
            <Col className="mb-5 mb-xl-0" xl="3">
              <div className="filterWrapper">
                <FilterComponent dataForTable={tableDataRef} handleApply={applyFilterChange}/>
              </div>
              </Col>
              <Col className="mb-5 mb-xl-0" xl="9">
                <Card className="shadow">
                  <CardHeader className="border-0">
                    <h3 className="mb-0">Score Card</h3>
                  </CardHeader>
                  <Table className="align-items-center table-flush" responsive>
                    <thead className="thead-light">
                      <tr>
                        <th scope="col">Skill</th>
                        <th scope="col">Total Questions</th>
                       
                        <th scope="col">Score</th>
                       
                        <th scope="col">Percentage</th>
                        <th scope="col">Enrollment Date</th>
                      </tr>
                    </thead>
                    {tableData.slice((page - 1) * itemsPerPage, page * itemsPerPage).map((item, key) => {

                      return <tbody key={key}>
                        <tr>
                          <th scope="row">
                            <Media className="align-items-center">

                              <div className="icon icon-shape bg-default text-white rounded-circle shadow">
                                <i className={`${item.icon}`}></i>
                              </div>&nbsp;&nbsp;
                              <Media>
                                <span className="mb-0 text-sm">
                                  {item.courseName}
                                </span>
                              </Media>
                            </Media>
                          </th>
                          
                          <td >{item.total_score}</td>
           
                          <td>{item.user_score}</td>
                          
                          <td>
                            <div className="d-flex align-items-center">
                              <span className="mr-2">{item.percentage}%</span>
                              <div>
                                <Progress
                                  max="100"
                                  value={item.percentage}
                                  barClassName={item.percentage > 40 ? "bg-green" : "bg-danger"}
                                />
                              </div>
                            </div>
                          </td>
                          <td>{item.date_of_enrollment}</td> 
                        </tr>
                      </tbody>
                    })}
                  </Table>

                </Card>
              </Col>
            
            </Row>
            {tableData.length > itemsPerPage ? (
                  <MuiThemeProvider theme={theme}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: '20px' }}>
                      <Pagination
                        linksShadow={4}
                        page={page}
                        setPage={handleChange}
                        perPage={itemsPerPage}
                        total={Math.ceil(tableData.length)}
                        size="large"
                        activeLinkColor='primary'
                        firstContent='First'
                        lastContent='Last'
                        firstLastColor='primary'
                        FirstLastComponent={Fab}
                      />
                    </div>
                  </MuiThemeProvider>
                ) : null}
          </Container>
        </div>
      }
    </>
  );
};

export default Index;
