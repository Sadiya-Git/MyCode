
import { useEffect, useState } from "react";
import {
  Card,
  CardHeader,
  CardBody,
  Form,
  Container,
  Row,
  Col,
  Button
} from "reactstrap";
// core components
import configData from '../../../config';
import { useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { ThreeDots } from 'react-loader-spinner'
import '@fortawesome/fontawesome-free/css/all.min.css';
import { useDispatch } from 'react-redux';
import useFetchData from '../component/fetchData';
import FeedbackItem from './feedbackinner'

const Feedback = () => {
  const dispatcher = useDispatch();
  const { fetchData } = useFetchData();

  const [feedback, setfeedback] = useState([]);
  const [feedbackYoutube, setfeedbackYoutube] = useState([]);
  const [totalScore, settotalScore] = useState('');
  const [userScore, setuserScore] = useState('');
  const account = useSelector((state) => state.account);
  const [loading, setloading] = useState(true);

  const location = useLocation();
  const url1 = configData.API_SERVER + 'UserAnswersWithFeedback';
  const url2 = configData.API_SERVER + 'calculateScore';
  const data = { "enrollment_id": location.state.enroll }, method = 'post';
  const [showExplanation, setShowExplanation] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [courseName, setcourseName] = useState('');
  const [courseQue, setcourseQue] = useState('');

  const onshowExplanation = (key) => {
    setSelectedItem(key);
    setShowExplanation(true);
  };
  const handleExplanationButton = (key) => {
    if (selectedItem === key) {
      hideExplanation();
    } else {
      onshowExplanation(key);
    }
  };
  const hideExplanation = () => {
    setSelectedItem(null);
    setShowExplanation(false);
  };

  useEffect(() => {
    fetchData(method, url1, data, account.token,
      (response) => {
        setfeedback(response.user_answers_with_feedback)
        setcourseName(response.course_name)
        setcourseQue(response.total_questions)
        response.user_answers_with_feedback.map((item, key) => {
          item.correct_options.map((item1) => {
            console.log("data is", item1.option_id)

          })
        })
        setfeedbackYoutube(JSON.parse(response.youtube_url))
      },
      (error) => {
        console.error("Error occurred:", error);
      }
    );
    TotalScore()
  }, [])
  const TotalScore = () => {
    fetchData(method, url2, data, account.token,
      (response) => {
        setloading(false)
        setuserScore(response.user_score)
        settotalScore(response.total_score)
      },
      (error) => {
        console.error("Error occurred:", error);
      }
    );
  }
  let handleDynamicContent = () => {
    if (feedbackYoutube != null) {
      return Object.keys(feedbackYoutube).map(item => {
        return (
          // <li className="dot-line-li">{feedbackYoutube[item]}</li>);
          <Row>
            <div className="col">
              <div className="card-profile-stats d-flex  ">
                <iframe width="560" height="315" src={feedbackYoutube[item]} title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
              </div>
            </div>
          </Row>)
      });
    }
    <h3>No Data provided</h3>

  }



  return (
    <>
      {loading ? <div
        className="header pb-8 pt-5 pt-lg-6 d-flex align-items-center"

      >
        <Container className="mt--10" fluid>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '70vh' }}>

            <ThreeDots
              visible={true}
              height="80"
              width="80"
              color="#172b4d"
              radius="9"
              ariaLabel="three-dots-loading"
              wrapperStyle={{}}
              wrapperClass=""
            />
          </div>

        </Container>
      </div> :
        <div className="header pb-8 pt-5 pt-md-5">

          {/* <span className="mask bg-gradient-default opacity-8" /> */}
          <Container className="align-items-center" fluid>
            <Row>
              <Col lg="7" xl="10">
                <h6 className="mb-0 display-3 text-gradient-darker">Results </h6>
              </Col>
            </Row>
          </Container><br />

          <Container fluid>

            <Row>
            <Col className="order-xl-1" xl="8" style={{ borderRadius: '10%' }}>
                <Card className="bg-secondary shadow " >
                  <CardHeader className=" border-0">
                    <Row className="align-items-center">
                      <Col xs="10">
                        <h3 className="mb-0 text-default " style={{ fontWeight: 'bolder' }}> {courseName}</h3>
                      </Col>
                      <Col xs="2">
                      <h3 className="mb-0 text-default " style={{ fontWeight: 'bolder' }}>  {userScore} out of {totalScore}</h3>
                      </Col>
                    </Row>
                    {/* <Row className="align-items-center">
                      <Col xs="10">
                        <h3 className="mb-0 text-white " style={{ fontWeight: 'bolder' }}> Based on your responses, your score is : {userScore} out of {totalScore}</h3>
                      </Col>
                      <Col xs="2">
                      </Col>
                    </Row> */}
                  </CardHeader>
                  <CardBody className="bg-gradient-white">
                    <Form>
                      <div className="pl-lg-2">
                        <div className="text-default" style={{ fontWeight: 'bolder' }}>

                          {feedback.map((item, key) => {
                            return (
                              < >
                                {key + 1}. {item.question.text}<br /><br />
                                <div style={{ marginLeft: "20px" }}>
                                  <FeedbackItem
                                    key={key}
                                    isCorrect={item.is_correct}
                                    optionId={item.chosen_option.option_id}
                                    optionText={item.chosen_option.text}
                                    feedback={item.feedback}
                                    correctOptions={item.correct_options}
                                  />
                                 
                                  {/* <FeedbackItem />
                                  {FeedbackItem({ isCorrect: item.is_correct, optionId: item.chosen_option.option_id, optionText: item.chosen_option.text })} */}
                                  <br />
                                  {/*{!item.is_correct ?

                                    <>
                                      {item.correct_options.map((item1) => {

                                        return <span className="text-success">{item1.option_id} : {item1.text}             <i className="fas fa-check-circle text-success"></i>
                                        </span>

                                      })}
                                    </>
                                    : null}

                                   {showExplanation && selectedItem === key && (
                                    <div>
                                      <br />                                    
                                      {item.feedback}
                                    </div>
                                  )}
                                  <br />
                                  <Button
                                    onClick={() => handleExplanationButton(key)}
                                    className="outline text-black bg-gradient-white"
                                    size="sm"
                                  >
                                    {selectedItem === key ? 'Hide Explanation' : 'Show Explanation'}
                                  </Button>
                                  <br />
                                  <br /> */}
                                </div>
                              </>
                            );
                          })}
                        </div>

                      </div>
                      <hr className="my-4 bg-default" />

                    </Form>
                  </CardBody>
                </Card>
              </Col>
              <Col className="order-xl-2 mb-5 mb-xl-0" xl="4">
                <Card className="card-profile shadow" >

                  <CardHeader className="text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
                    <div className="d-flex justify-content-between">
                      <h3 className="mb-0 text-gradient-default " style={{ fontWeight: 'bolder' }}>You can deep dive into these videos related to these modules and enhance your learning experience.</h3>
                    </div>
                  </CardHeader>
                  <CardBody className="text-center border-2  ">
                    {handleDynamicContent()}
                    <Row className="justify-content-center">
                      {/* <Col xs="1"></Col> */}
                      <div className="col">
                        <div className="card-profile-image">
                          Reach out to our support team for any queries or concerns. Send a mail at demo@certify360.com
                          {/* Ensure a thorough understanding of the content by watching the videos attentively, and complement your preparation for  certification by referring to additional study materials.<br /> */}
                          <p className="text-success" style={{ fontWeight: 'bolder' }}> Happy Learning!</p>

                        </div>
                      </div>
                    </Row>
                  </CardBody>
                </Card>
              </Col>
             
            </Row>
          </Container>
        </div>
      }
    </>
  );
};

export default Feedback;
