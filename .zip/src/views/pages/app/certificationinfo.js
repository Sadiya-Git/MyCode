import React, { useState } from 'react';
import './certificate.css';
import {Container} from 'reactstrap'

function App() {
  const [selectedSection, setSelectedSection] = useState(null);

  const courseName = "AZ-104T00-A: Microsoft Azure Administrator Course Overview";
  const courseDescription = `Embark on a journey to master cloud administration with our AZ-104T00-A: Microsoft Azure Administrator course. This comprehensive azure 104 full course equips you with the essentials of Azure Active Directory, governance, and Azure administration, ensuring you can manage identities, compliance, and resources effectively. Delve into virtual networking and intersite connectivity to maintain robust and secure network infrastructures. Learn to optimize network traffic and Azure storage solutions, and gain hands-on experience managing Azure Virtual Machines. Explore serverless computing with Azure services, and bolster your skills in data protection and monitoring. With our azure 104 online training, you'll apply these concepts in real-world scenarios, preparing you for challenges in the Azure ecosystem.`;

  const coursePrerequisites = (
    <>
            <h2>Course Prerequisites</h2>
      <ul>
        <li>Basic understanding of on-premises virtualization technologies, including VMs, virtual networking, and virtual hard disks.</li>
        <li>Basic understanding of network configuration, including TCP/IP, Domain Name System (DNS), VPNs, firewalls, and encryption technologies.</li>
        <li>Basic understanding of Active Directory concepts, including users, groups, and role-based access control.</li>
        <li>Basic knowledge of resilience and disaster recovery, including backup and restore operations.</li>
        <li>Some hands-on experience with Azure, such as creating virtual machines and using Azure portals, Azure PowerShell, or Azure CLI.</li>
        <li>Familiarity with using Windows or Linux operating systems.</li>
        <li>Basic understanding of cloud computing concepts.</li>
      </ul>
      
      
    </>
  );

  const examInformation = (
    <>
      <h2>Exam Information</h2>
      <table>
        <tbody>
          <tr>
            <th>Exam Component</th>
            <th>Details</th>
          </tr>
          <tr>
            <td>Exam Name</td>
            <td>AZ-104T00-A: Microsoft Azure Administrator</td>
          </tr>
          <tr>
            <td>Exam Type</td>
            <td>Multiple Choice Questions (MCQs)</td>
          </tr>
          <tr>
            <td>Total Questions</td>
            <td>40</td>
          </tr>
          <tr>
            <td>Passing Score</td>
            <td>700 (out of 1000)</td>
          </tr>
          <tr>
            <td>Exam Duration</td>
            <td>180 minutes</td>
          </tr>
          <tr>
            <td>Language</td>
            <td>English</td>
          </tr>
          <tr>
            <td>Exam Provider</td>
            <td>Microsoft</td>
          </tr>
          <tr>
            <td>Exam Focus</td>
            <td>Administration and management of Azure services and resources</td>
          </tr>
          <tr>
            <td>Exam Topics</td>
            <td>
              <ul>
                <li>Manage Azure identities and governance</li>
                <li>Implement and manage storage</li>
                <li>Deploy and manage Azure compute resources</li>
                <li>Configure and manage virtual networking</li>
                <li>Monitor and back up Azure resources</li>
              </ul>
            </td>
          </tr>
          <tr>
            <td>Exam Registration</td>
            <td>Through Microsoft's official certification website or authorized testing centers</td>
          </tr>
          <tr>
            <td>Retake Policy</td>
            <td>Candidates can retake the exam after 24 hours if necessary</td>
          </tr>
          <tr>
            <td>Certification Validity</td>
            <td>1 year (can be renewed)</td>
          </tr>
          <tr>
            <td>Recommended Training</td>
            <td>Microsoft Azure Administrator Training</td>
          </tr>
        </tbody>
      </table>
    </>
  );

  const roadMap = (
    <>
      <h2>Road Map for Certification</h2>
      <p style={{fontWeight:'bold'}}>
        The AZ-104T00-A course is designed for professionals managing Azure environments, focusing on configuration, governance, and administration.
      </p>
      <ul>
        <li>Systems Administrators</li>
        <li>IT Professionals with Azure experience</li>
        <li>Cloud Solutions Architects</li>
        <li>DevOps Engineers</li>
        <li>Network Engineers</li>
        <li>Security Engineers</li>
        <li>Professionals preparing for the Microsoft Azure Administrator certification</li>
      </ul>
      <h2>Learning Objectives - What you will Learn in this AZ-104T00-A: Microsoft Azure Administrator?</h2>
      <ul>
        <li>Understand and manage Azure identities using Azure Active Directory, including users and groups.</li>
        <li>Implement governance through subscription management, Role-Based Access Control (RBAC), and Azure policies to maintain compliance.</li>
        <li>Utilize Azure Administration tools like Azure Resource Manager, Azure Portal, Azure PowerShell, and Azure CLI to manage resources efficiently.</li>
        <li>Configure and secure virtual networking, understand IP addressing, network security groups, and implement Azure Firewall and DNS.</li>
        <li>Establish intersite connectivity through VNet peering, VPN Gateway connections, ExpressRoute, and Virtual WAN.</li>
        <li>Manage network traffic by setting up routing, endpoints, Azure Load Balancer, Azure Application Gateway, and Traffic Manager.</li>
        <li>Administer Azure Storage solutions including storage accounts, blob storage, storage security, Azure Files, and File Sync.</li>
        <li>Plan, create, and maintain Azure virtual machines with a focus on scalability and availability.</li>
        <li>Deploy serverless computing features with Azure App Service, container services, and Azure Kubernetes Service.</li>
        <li>Protect data with Azure backup solutions and monitor cloud services using Azure Monitor, Alerts, Log Analytics, and Network Watcher.</li>
      </ul>
      <h2>Career growth after the course:</h2>
      <p style={{fontWeight:'bold'}}>
        Completing the AZ-104T00-A: Microsoft Azure Administrator course equips students with vital cloud management skills, crucial for roles like Azure Administrator, Cloud Architect, and DevOps Engineer. Industries spanning finance to healthcare seek professionals adept in Azure services, reflecting the broad applicability of these competencies. The azure 104 full course fosters expertise in managing Azure subscriptions, configuring virtual networking, and implementing storage solutions, among others. By pursuing azure 104 online training, students position themselves at the forefront of cloud technology trends, with the Azure platform's growing adoption indicating a robust future scope. This training is a strategic investment in a career marked by growth and opportunities in the evolving IT landscape.
      </p>
      <h2>Top Companies Hiring for AZ-104T00-A: Microsoft Azure Administrator Certified Professionals</h2>
      <p style={{fontWeight:'bold'}}>

        Enhance your career with the AZ-104T00-A: Microsoft Azure Administrator course. Top employers like Microsoft, Amazon Web Services, IBM, Deloitte, and Accenture seek skilled professionals to manage their Azure environments. Get certified and join the ranks of in-demand Azure Administrators in the tech industry's leading companies.
      </p>
    </>
  );

  return (
    <div className=" pt-lg-5 d-flex align-items-center">
        <Container className="mt--10" fluid>
      <header className="course-header">
      <h1>{courseName}</h1>
      <p style={{fontWeight:'bold'}}>
{courseDescription}</p>
    </header>
    <div className="buttons">
      <button onClick={() => setSelectedSection('prerequisites')}>Course Prerequisites</button>
      <button onClick={() => setSelectedSection('examInformation')}>Exam Information</button>
      <button onClick={() => setSelectedSection('roadMap')}>Road Map for Certification</button>
      <button onClick={() => setSelectedSection(null)}>Show All</button>
    </div>
    <div className="content">
      {selectedSection === 'prerequisites' && coursePrerequisites}
      {selectedSection === 'examInformation' && examInformation}
      {selectedSection === 'roadMap' && roadMap}
      {selectedSection === null && (
        <>
          {coursePrerequisites}
          {examInformation}
          {roadMap}
        </>
      )}
    </div>
    </Container>
  </div>
  );
}

export default App;
