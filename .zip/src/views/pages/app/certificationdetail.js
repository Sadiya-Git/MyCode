
import React,{ useEffect, useState } from "react";
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  Form,
  Container,
  Row,
  Col,
  Modal
} from "reactstrap";
import OutlinedInput from '@mui/material/OutlinedInput';
// core components
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import configData from '../../../config';
import { useNavigate } from "react-router-dom"
import { useSelector } from 'react-redux';
// import Loader from 'react-spinner-loader';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import { ThreeDots } from 'react-loader-spinner'
import { darken } from '@mui/material/styles';
import Box from '@mui/material/Box';
import clsx from 'clsx';
import { motion } from 'framer-motion';
import {
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from 'reactstrap';
import useFetchData from '../component/fetchData';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { useTheme } from '@mui/material/styles';
const Profile = () => {
  const { fetchData } = useFetchData();
  const theme = useTheme();
  const [courses, setSelectedCourses] = React.useState([]);
  const [showUpgrade, setshowUpgrade] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const [period, setPeriod] = useState('year');
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [certificate, setcertificate] = useState([]);
  const [keysForKnow, setkeysForKnow] = useState([]);
  const [whattoknow, setwhattoknow] = useState([]);
  const [loading, setloading] = useState(true);
  const [messageForModel, setMessageforModel] = useState('');
  const [dataForModel, setDataForModel] = useState([])
  const [dataForOffers, setDataForOffers] = useState(null);
  const [refrenceLink, setrefrenceLink] = useState('');
  const account = useSelector((state) => state.account);
  const [dropdownVal, setDropdownVal] = useState()
  const [noofQuestion, setnoofQuestion] = useState('10');
  const categories = useSelector((state) => state.domainCeretifctaes);
  const [coursesForDropdown, setCoursesForDropdown] = useState({})
  // const [noofquestion, setnoofquestion] = useState('');
  const [duration, setduration] = useState('10');
  const plansLabel = {
    "Premium Member": 'Everything is free and :',
    "Certificate Member": " Everything is free and :",
    "Free Member": "For people just getting started with Certify360"
  }
  const plansButtonLabel = {
    "Premium Member": 'Upgrade Subscription',
    "Certificate Member": " Upgrade Subscription",
    "Free Member": "Your current plan"
  }
  const handleFilterChange = (value) => {
    setPeriod(value)
  }
  const toggle = () => setDropdownOpen((prevState) => !prevState);
  const handleNoofChange = (code) => {
    console.log("duration is", code)
    setnoofQuestion(code)
    setduration(code)
  }
  const url = configData.API_SERVER + 'getSubDomainDetails';
  var data, method = 'post';
  if (location.state.type === "Practice") {
    data = { "subDomainId": location.state.id }
  } else {
    data = { "subDomainId": location.state.id, type: location.state.type }

  }

  useEffect(() => {
    fetchData(method, url, data, account.token,
      (response) => {
        setloading(false)
        setcertificate(response);

        if (location.state.type === "Mock") {
          setduration(response.duration)
          setnoofQuestion(response.noOfQuestions)
        }
        setwhattoknow(response.whatNeedToKnow != null ? JSON.parse(response.whatNeedToKnow) : null);
        setkeysForKnow(Object.keys(whattoknow))
        setrefrenceLink(response.reference_link)
        // setduration()
        console.log("object keys aare", Object.keys(whattoknow))
      },
      (error) => {
        console.error("Error occurred:", error);
      }
    );
    // handleDynamicContent()
  }, [])



  let handleDynamicContent = () => {
    if (whattoknow != null) {
      return (
        <ul className="dot-line-ul text-white">
          {Object.keys(whattoknow).map(item => (
            // Object.keys(item).map(item1 => (
            <li key={item} className="dot-line-li">{whattoknow[item]}</li>
            // ))
          ))}
        </ul>
      );
    } else {
      return <h3>No Data provided</h3>;
    }
  };
  let handleReferenceLink = () => {
    if (refrenceLink != null) {
      return (
        <a href={refrenceLink} target="_blank" className="text-white" style={{ textDecoration: 'underline' }} >{refrenceLink}</a>
      );
    } else {
      return <h3>No Data provided</h3>;
    }
  };
  const getOffers = async (header) => {
    setloading(true)
    const offerresponse = await axios.get(configData.API_SERVER + 'offer', header);
    const dataResponse = offerresponse.data;
    setMessageforModel(dataResponse.message)
    setDataForModel(dataResponse.plans)
    setDataForOffers(dataResponse)
    console.log(location.state.id, 'wewew')
    const uniqueCourseName = [...new Set(categories.certificates.response.map(item => item.courseName))];
    
    const selectedCertificate = [...new Set(categories.certificates.response)].filter(item => item.courseId === location.state.id);
    //const itemSelected = { label: selectedCertificate[0].courseName, value: selectedCertificate[0].courseName }
    setDropdownVal(uniqueCourseName)
    const newArr =[].concat(selectedCertificate[0].courseName)
    setSelectedCourses(newArr)


    setloading(false)
  }
  const getQuiz = () => {
    let header = {
      headers: { 'Authorization': "Bearer " + account.token }
    };
    axios
      .post(configData.API_SERVER + 'enrollUser', {
        "course_id": location.state.id,
        "no_of_question": noofQuestion,
        "enroll_type": location.state.type
      }, header)
      .then(function (response) {
        console.log("enrollment id is", response.data.enrollment_id)
        if (response.data.enrollment_id == -1) {
          getOffers(header)
          setshowUpgrade(true)
        } else {
          navigate(`/admin/quiz`, { state: { id: location.state.id, enroll: response.data.enrollment_id, courseLevel: certificate.difficulty, domainetail: response.data, randomquestion: response.data.questions_random, currentQuestion: response.data.questions_random[0].id, questionid: response.data.questions_random[0].question_id, currentObj: response.data.questions_random[0], no_OfQuestion: noofQuestion, quizName: certificate.courseName, quizDuration: duration } });
        }
      })
  }
  const toggleModal = () => {
    setshowUpgrade(false)
  }
  const handleSelect = (e) => {
    setDropdownVal({ label: e.value, value: e.value })
  }
  const handleShowCardPopup = (valueOfFilter) => {
    const dataToDisplayForPayment = dataForModel.filter(item => item.planName === valueOfFilter);
    const planType = dataToDisplayForPayment[0].planType;
    const costForPlans = period === "month" ? dataToDisplayForPayment[0].planCostMonthly : dataToDisplayForPayment[0].planCostYearly
    const costCalculated = Number(costForPlans.split('$')[1])*courses.length;
    const setCostCalclated = `${dataForOffers.currency}$${costCalculated}`
    const discountfetched = dataToDisplayForPayment[0].discount.split('%')[0]
    const calculatedDiscount = ((Number(discountfetched)*courses.length) / 100) * (Number(costCalculated));
    const setCalculatedDiscount = `${dataForOffers.currency}$${calculatedDiscount}`
    const payableAmountCalculated = (costCalculated - calculatedDiscount);
    const payableAmountToSet = `${dataForOffers.currency}$${payableAmountCalculated}`
    if (dataToDisplayForPayment[0].planName === "Certificate Member") {
      navigate(`/admin/payment`, {
        state: {
          frequency: dataToDisplayForPayment[0].
            planName === "Certificate Member" ? "none" : period, planName: planType
          , subscriptionAmount: setCostCalclated, discountForCourse: setCalculatedDiscount, amountToPay: payableAmountToSet, planName: dataToDisplayForPayment[0].
            planName, certificateSelected: courses, categoriesResponse: categories.certificates.response, cost: payableAmountCalculated, currency: dataForOffers.currency,coursesSelected:courses
        }
      })
    } else {
      navigate(`/admin/payment`, {
        state: {
          frequency: dataToDisplayForPayment[0].
            planName === "Certificate Member" ? "none" : period, planName: planType
          , subscriptionAmount: setCostCalclated, discountForCourse: setCalculatedDiscount, amountToPay: payableAmountToSet, planName: dataToDisplayForPayment[0].
            planName, cost: payableAmountCalculated, currency: dataForOffers.currency
        }
      })
    }
  }
  const handleChange=(event)=>{
      const {
        target: { value },
      } = event;
      setSelectedCourses(
        // On autofill we get a stringified value.
        typeof value === 'string' ? value.split(',') : value,
      );
  }
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 230,
      whitespace:'nowrap'
    },
  },
};
const getStyles=(name, courses, theme)=> {
  return {
    fontWeight:
      courses.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
        whiteSpace:'pre-wrap'    
  };
}

  return (
    <>
      {loading && certificate && whattoknow && keysForKnow ? <div
        className="header pb-8 pt-5 pt-lg-6 d-flex align-items-center"
      >
        <Container className="mt--10" fluid>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '70vh' }}>

            <ThreeDots
              visible={true}
              height="80"
              width="80"
              color="#172b4d"
              radius="9"
              ariaLabel="three-dots-loading"
              wrapperStyle={{}}
              wrapperClass=""
            />
          </div>

        </Container>
      </div> :
        <div
          className="header pb-8 pt-5 pt-lg-8 d-flex align-items-center"
        >
          <Container className="mt--10" fluid >
            {showUpgrade ? <Modal
              className="modal-dialog-centered divClassNameForModelPlans"
              contentClassName="bg-gradient-white"
              isOpen={showUpgrade}
              toggle={() => toggleModal()}
            >
              <Stack sx={{ width: '100%' }} spacing={2}>
                <Alert severity="info">{messageForModel}</Alert>
              </Stack>
              <div className="modal-header">
                <h4 className="heading mt-4">   <i className="ni ni-lock-circle-open ni-3x" /><b>Upgrade your plan to unclock..!</b></h4>
                <button
                  aria-label="Close"
                  className="close"
                  data-dismiss="modal"
                  type="button"
                  onClick={() => toggleModal()}
                >
                  <span aria-hidden={true}>×</span>
                </button>
              </div>



              <div className="modal-body modelBodyOPlans">
                <Row className="justify-content-start">
                  {dataForModel.map(item => {
                    return (
                      <Col className="order-xl-1 plansClass" xl="4" xs="12">
                        <h2 className="heading text-gradient-default plansHeading">
                          {item.planName}
                        </h2>
                        <div className="costForCoursePlans priceHeading">
                          {item.plan}
                        </div>
                        {item.planName === "Premium Member" ?
                          <div className="flex billingContainer">
                            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 0.2 } }}>
                              <Box
                                className="filterContainer"
                                sx={{ backgroundColor: (theme) => darken(theme.palette.background.default, 0.05) }}
                              >
                                <Box
                                  component="button"
                                  className={clsx(
                                    'h-40 items-center px-16 cursor-pointer rounded-full font-medium buttonsForPeriod',
                                    period === 'year' && 'shadow'
                                  )}
                                  onClick={() => handleFilterChange('year')}
                                  sx={{ backgroundColor: period === 'year' ? 'background.paper' : '' }}
                                  type="button"
                                >
                                  Yearly billing
                                </Box>

                                <Box
                                  component="button"
                                  className={clsx(
                                    'h-40 items-center px-16 cursor-pointer rounded-full font-medium buttonsForPeriod',
                                    period === 'month' && 'shadow'
                                  )}
                                  onClick={() => handleFilterChange('month')}
                                  sx={{ backgroundColor: period === 'month' ? 'background.paper' : '' }}
                                  type="button"
                                >
                                  Monthly billing
                                </Box>
                              </Box>
                            </motion.div>
                          </div>
                          : null}
                        {
                          item.planName === "Certificate Member" ? <div>
                            <FormControl sx={{ m: 1, width: 230,height:'auto' }}>
                              <InputLabel id="demo-multiple-name-label">Name</InputLabel>
                              <Select
                                labelId="demo-multiple-name-label"
                                id="demo-multiple-name"
                                multiple
                                value={courses}
                                onChange={handleChange}
                                input={<OutlinedInput label="Name" />}
                                MenuProps={MenuProps}
                              >
                                {dropdownVal.map((name) => (
                                  <MenuItem
                                    key={name}
                                    value={name}
                                    style={getStyles(name, courses, theme)}
                                  >
                                    {name}
                                  </MenuItem>
                                ))}
                              </Select>
                            </FormControl>
                          </div> : null
                        }
                        <div className="costForCoursePlans planCostContainer">
                          <div className="planCostLabel">Plan Cost:</div>
                          {item.planType === "free" ? "$0" : period === "month" ? item.planCostMonthly : item.planCostYearly}
                        </div>
                        <Button
                          className={item.planName === "Free Member" ? "text-white bg-gradient-gray mb-4 pointerEventsNone" : " text-white bg-gradient-default mb-4"}
                          onClick={() => handleShowCardPopup(item.planName)}
                        >
                          {plansButtonLabel[item.planName]}
                        </Button>
                        <h4 className="mb-4 plansFeaturesStart">
                          {plansLabel[item.planName]}
                        </h4>
                        {item.features.map(item => {
                          return (<h4 className=" text-gradient-default mb-4 flexForFeatures">
                            <i className="ni ni-check-bold ni-1x" />
                            <div className="plansFeaturesForPlans">{item}</div>
                          </h4>)
                        })}
                      </Col>
                    )
                  })

                  }
                </Row>

              </div>
              <div className="modal-footer">

                <Button
                  className=" text-white bg-gradient-default mb-4"
                  type="button"
                  onClick={() => toggleModal()}
                >
                  Close
                </Button>
              </div>
            </Modal> : null}

            <Row>
              <Col className="order-xl-2 mb-5 mb-xl-0" xl="4">
                <Card className="card-profile shadow" >

                  <CardHeader className="text-center border-0 pt-8 pt-md-4 pb-0 pb-md-4">
                    <div className="d-flex justify-content-between">
                      <h3 className="mb-0 text-gradient-default " style={{ fontWeight: 'bolder' }}>At a Glance</h3>
                    </div>
                  </CardHeader>
                  <CardBody className="pt-0 ">
                    <Row>
                      <div className="card-profile-stats d-flex  border-0  pt-md-2 pb-0">
                        <div className="icon icon-shape bg-gradient-default text-white rounded-circle shadow">
                          <i class="fa-solid fa-clock "></i>
                        </div>
                      </div>
                      <div className="col" xl="2">
                        <div className="card-profile-stats d-flex  ">
                          {/* <h3 className="text-gradient-default " style={{ fontWeight: 'bolder' }}>Duration: {`${noofQuestion} Min`}</h3> */}

                          <h3 className="text-gradient-default " style={{ fontWeight: 'bolder' }}>Duration: {location.state.type === "Mock" ? `${duration} Min` : `${noofQuestion} Min`}</h3>
                        </div>
                      </div>
                    </Row>
                    {/* <Row>
                      <div className="card-profile-stats d-flex  border-0  pt-md-2 pb-0">
                        <div className="icon icon-shape bg-gradient-default text-white rounded-circle shadow">
                          <i class="fa-solid fa-certificate "></i>
                        </div>
                      </div>
                      <div className="col" xl="2">
                        <div className="card-profile-stats d-flex  ">
                          <h3 className="text-gradient-default " style={{ fontWeight: 'bolder' }}>Level: {certificate.difficulty}</h3>
                        </div>
                      </div>
                    </Row> */}
                    <Row>
                      <div className="card-profile-stats d-flex  border-0  pt-md-2 pb-0">
                        <div className="icon icon-shape bg-gradient-default text-white rounded-circle shadow">
                          <i class="fa-solid fa-question"></i>
                        </div>
                      </div>
                      <div className="col" xl="2">
                        <div className="card-profile-stats d-flex  ">
                          <h3 className="text-gradient-default " style={{ fontWeight: 'bolder' }}>No of Question's:&nbsp;
                            {location.state.type === "Practice" ? <Dropdown isOpen={dropdownOpen} toggle={toggle}>
                              <DropdownToggle caret>
                                {noofQuestion}
                              </DropdownToggle>
                              <DropdownMenu>
                                <DropdownItem onClick={() => handleNoofChange('10')}>10</DropdownItem>
                                <DropdownItem onClick={() => handleNoofChange('20')}>20</DropdownItem>
                                <DropdownItem onClick={() => handleNoofChange('30')}>30</DropdownItem>
                                {/* Add more options as needed */}
                              </DropdownMenu>
                            </Dropdown> : `${noofQuestion} `}
                          </h3>
                        </div>
                      </div>
                    </Row>


                    <Row className="justify-content-center">
                      <Col xs="1"></Col>
                      <Col xs="4">
                        <div className="card-profile-image">
                          <Button
                            // color="primary"
                            // to="/admin/quiz"
                            // onClick={(e) => e.preventDefault()}
                            className="text-white bg-gradient-default"
                            size="lg"
                            // tag={Link}
                            onClick={() => getQuiz(certificate.courseId)}

                          >
                            Start Quiz
                          </Button>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </Col>
              <Col className="order-xl-1  mb-5 mb-xl-0" xl="8" style={{ borderRadius: '10%' }}>
                <Card className="bg-secondary shadow " >
                  <CardHeader className="bg-gradient-default border-0">
                    <Row className="align-items-center">
                      <Col xs="10">
                        <h3 className="mb-0 text-white " style={{ fontWeight: 'bolder' }}>{certificate.courseName}</h3>
                      </Col>


                    </Row>
                    <br></br>
                    <Row className="align-items-center">
                      <Col xs="12">
                        <h3 className="mb-0 text-white " >Reference Link: {handleReferenceLink()} </h3>
                      </Col>
                    </Row>
                  </CardHeader>
                  <CardBody className="bg-gradient-default">

                    <Form>

                      <h3 className="heading-small text-white mb-4">

                        What you'll need to know?
                      </h3>

                      <div className="pl-lg-4">

                        <ul className="dot-line-ul text-white">
                          {handleDynamicContent()}
                          {/* return <li className="dot-line-li">{whattoknow[item]}</li> */}
                        </ul>

                      </div>

                      <hr className="my-4 bg-white" />

                    </Form>
                  </CardBody>
                </Card>
              </Col>

            </Row>
          </Container>


        </div>
      }
    </>

  );
};

export default Profile;
