import React, { useState, useEffect } from "react";
import {
  Button,
  Card,
  CardBody,
  FormGroup,
  Form,
  Input,
  Container,
  Row,
  Col,
  CardTitle,
  Nav,
  NavItem,
  NavLink,
  TabContent,
  TabPane,
  Label,
} from "reactstrap";
import { ThreeDots } from 'react-loader-spinner'
import Pagination from 'react-mui-pagination';
import Fab from '@material-ui/core/Fab';
import { MuiThemeProvider, createTheme } from '@material-ui/core/styles';
import { useNavigate } from "react-router-dom"
import { useDispatch, useSelector } from 'react-redux';
import useFetchData from '../component/fetchData';
import configData from '../../../config';
import SearchIcon from '@mui/icons-material/Search';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import {faFilterCircleDollar} from '@fortawesome/free-solid-svg-icons';
import {SET_DOMAIN_CERTIFICATES} from '../../../store/actions';
const theme = createTheme({
  palette: {
    primary: {
      main: '#32325D'
    }
  }
});

const Certification = () => {
  const navigate = useNavigate();
  const { fetchData } = useFetchData();
  const dispatcher = useDispatch();
  const [certificate, setCertificate] = useState([]);
  const [loading, setLoading] = useState(true);
  const account = useSelector((state) => state.account);
  const [selectedDomains, setSelectedDomains] = useState([]);
  const [category, setCategory] = useState([]);
  const [originalCategories, setoriginalCategories] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('mostRecent');
  const url = configData.API_SERVER + 'getSubDomain';
  const data = { "domainId": 1 }, method = 'post';

  useEffect(() => {
    fetchData(method, url, data, account.token,
      (response) => {
        setLoading(false)
        setCertificate(response)
        
        const categories = [...new Set(response.map(course => course.category))];
        dispatcher({
          type: SET_DOMAIN_CERTIFICATES,
          payload: {response},
        });
        setCategory(categories);
        setoriginalCategories(categories);
        // const empResult = response;
        // console.log("data is",response.length)
        setnoOfPages(Math.ceil(response.length / itemsPerPage))
      },
      (error) => {
        console.error("Error occurred:", error);
      }
    );
  }, [])

  // Function to toggle selected domain filters
  const toggleDomainFilter = (domain) => {
    if (selectedDomains.includes(domain)) {
      setSelectedDomains(selectedDomains.filter((selected) => selected.toLowerCase() !== domain.toLowerCase()));
    } else {
      setSelectedDomains([...selectedDomains, domain]);
    }
  };
  
  const handleSearchChange = (e) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(query);

    if (query.trim() !== '') {
      const filtered = category.filter((domain) =>
        domain.toLowerCase().includes(query)
      );
      setCategory(filtered);
    } else {
      setCategory(originalCategories);
    }
  };

  const itemsPerPage = 9;
  const [page, setPage] = useState(1);
  const [noOfPages, setnoOfPages] = useState('');

  const handleChange = (event, value) => {
    setPage(value);
  };

  const handleSelectAllDomains = (e) => {
    const isChecked = e.target.checked;
    if (isChecked) {
      setSelectedDomains(category);
    } else {
      setSelectedDomains([]);
    }
  };

  const filteredCertificates = certificate.filter(
    (item) =>
      (selectedDomains.length === 0 || selectedDomains.includes(item.category))
  );

  const handleButtonClick = (buttonType, courseId,courseName) => {
    // Implement the logic for each button type here
    // console.log(`Button "${buttonType}" clicked for course with ID: ${courseId}`);
    if(buttonType==="Mock"){
      navigate(`/admin/certifications/details`, { state: { id: courseId ,type:"Mock"} });

    }
    if(buttonType==="Practice"){
      navigate(`/admin/certifications/details`, { state: { id: courseId,type:"Practice" } });

    }
    if(buttonType==="Study"){
      navigate(`/admin/learning/details`, { state: { id: courseId,coursename:courseName } });
    }
  };

  return (
    <>
      {loading ? (
        <div className="header pb-8 pt-5 pt-lg-6 d-flex align-items-center">
          <Container className="mt--10" fluid>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '70vh' }}>
              <ThreeDots
                visible={true}
                height="80"
                width="80"
                color="#172b4d"
                radius="9"
                ariaLabel="three-dots-loading"
                wrapperStyle={{}}
                wrapperClass=""
              />
            </div>
          </Container>
        </div>
      ) : (
        <div className="header pb-8 pt-5 pt-md-5">
          <Container className="align-items-center" fluid>
            <Row>
              <Col lg="7" xl="10">
                <h1 className="display-3 text-gradient-darker">Prepare for Certifications</h1>
              </Col>
            </Row>
          </Container>
          <Container fluid>
            <Row>
              {/* Filteration Tabs */}
              <Col xs="12" sm="2">
                <Nav tabs>
                  <NavItem>
                    <NavLink
                      className={activeTab === 'mostRecent' ? 'active' : ''}
                      onClick={() => setActiveTab('mostRecent')}
                      style={{ color: '#32325D', fontWeight: 'bold' }}
                    >
                      Most Recent
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === 'viewAll' ? 'active' : ''}
                      onClick={() => setActiveTab('viewAll')}
                      style={{ color: '#32325D', fontWeight: 'bold' }}
                    >
                      View All
                    </NavLink>
                  </NavItem>
                </Nav>
                <TabContent activeTab={activeTab}>
                  <TabPane tabId="mostRecent">
                    <FormGroup></FormGroup>
                    <Card className="p-3">
                      <h2 className="mb-3 font-weight-bold text-gradient-darker">Category</h2>
                      {category.slice(0, 5).map((domain) => (
                        <FormGroup check key={domain}>
                          <Label check >
                            <Input
                              type="checkbox"
                              checked={selectedDomains.includes(domain)}
                              onChange={() => toggleDomainFilter(domain)}
                            />
                            {' '}
                            <span className="ml-2 font-weight-bold" style={{ color: '#32325D !important' }}>{domain.charAt(0).toUpperCase() + domain.slice(1)}</span>
                          </Label>
                        </FormGroup>
                      ))}
                    </Card>
                    <br></br>
                  </TabPane>
                  <TabPane tabId="viewAll">
                    <FormGroup>
                      <div style={{ position: 'relative' }}>
                        <FontAwesomeIcon icon={faSearch} style={{ position: 'absolute', top: '50%', right: '10px', transform: 'translateY(-50%)' }} />
                        <Input
                          type="text"
                          value={searchQuery}
                          onChange={handleSearchChange}
                        />
                      </div>
                    </FormGroup>
                    <Card className="p-3">
                      <div className="category-list" style={{ maxHeight: '200px', overflowY: 'auto' }}>
                        <h2 className="mb-3 font-weight-bold text-gradient-darker">Category</h2>
                        {category.map((domain) => (
                          <FormGroup check key={domain}>
                            <Label check>
                              <Input
                                type="checkbox"
                                checked={selectedDomains.includes(domain)}
                                onChange={() => toggleDomainFilter(domain)}
                              />
                              {' '}
                              <span className="ml-2 font-weight-bold" style={{ color: '#32325D !important' }}>{domain.charAt(0).toUpperCase() + domain.slice(1)}</span>
                            </Label>
                          </FormGroup>
                        ))}
                      </div>
                    </Card>
                    <br></br>
                    <Card className="p-3">
                      <FormGroup check>
                        <Label check>
                          <Input
                            type="checkbox"
                            checked={selectedDomains.length === category.length}
                            onChange={handleSelectAllDomains}
                          />
                          {' '}
                          <span className="ml-2 font-weight-bold" style={{ color: '#32325D !important' }}>{"Select All"}</span>
                        </Label>
                      </FormGroup>
                    </Card>
                  </TabPane>
                </TabContent>
              </Col>
              <Col xs="12" sm="10">
                <Row>
                  {filteredCertificates
                    .slice((page - 1) * itemsPerPage, page * itemsPerPage)
                    .map((item, key) => {
                      return <Col lg="8" xl="4" key={key}>
                      <hr className="my-4" />
                      <Card className="card-stats mb-6 mb-xl-0">
      <CardBody>
        <Row>
          <div className="col">
            <CardTitle tag="h5" className="text-uppercase text-muted mb-0"></CardTitle>
            <span className="h2 font-weight-bold text-black mb-0">
              {item.courseName}
            </span>
          </div>
          <div className="col-auto">
          <i className="fa fa-info-circle" onClick={()=>alert("hello ..!")}/>
          </div>
        </Row>
        <Row className="mt-3 mb-0 text-sm">
          <Col className="col-4">
            <Button
              className="text-white bg-gradient-default"
              onClick={() => handleButtonClick("Study", item.courseId, item.courseName)}
              size="sm"
              block
            >
              Study
            </Button>
          </Col>
          <Col className="col-4">
            <Button
              className="mr-2 text-white bg-gradient-default"
              onClick={() => handleButtonClick("Practice", item.courseId)}
              size="sm"
              block
            >
              Practice
            </Button>
          </Col>
          <Col className="col-4">
            <Button
              className="mr-3 text-white bg-gradient-default"
              onClick={() => handleButtonClick("Mock", item.courseId)}
              size="sm"
              block
            >
              Mock Exam
            </Button>
          </Col>
        </Row>
      </CardBody>
    </Card>
                    </Col>
                    
                    })}
                </Row>
                {filteredCertificates.length > itemsPerPage ? (
                  <MuiThemeProvider theme={theme}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: '20px' }}>
                      <Pagination
                        linksShadow={4}
                        page={page}
                        setPage={handleChange}
                        perPage={itemsPerPage}
                        total={Math.ceil(certificate.length)}
                        size="large"
                        activeLinkColor='primary'
                        firstContent='First'
                        lastContent='Last'
                        firstLastColor='primary'
                        FirstLastComponent={Fab}
                      />
                    </div>
                  </MuiThemeProvider>
                ) : null}
              </Col>
             
            </Row>
          </Container>
        </div>
      )}
    </>
  );
};

export default Certification;
