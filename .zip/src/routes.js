
import Index from "views/Index.js";
import Profile from "views/pages/app/profile";
import Register from "views/pages/auth/register.js";
import Login from "views/pages/auth/login.js";
import App from "views/pages/auth/app.js";
import Tables from "views/pages/app/tables.js";
import Quiz from "views/pages/app/quiz.js";
import Category from "views/pages/app/category.js"
import CertificationDetail from "views/pages/app/certificationdetail.js"
import Certification from "views/pages/app/certification.js"
import Feedback from "views/pages/app/feedback.js"
import Learning from "views/pages/app/learning.js"
import DetailLearning from "views/pages/app/detailLearning.js"
import DetailLearningModule from "views/pages/app/learnModules.js"
import Graph from "views/pages/graph.js"
import CardPage from "views/pages/CardPage";
import Forgetpass from "views/pages/auth/forgetpass";
import Confirmpassword from "views/pages/auth/confirmpassword";
import CertificateDetailsModule from "views/pages/app/certificateDetailsModule"
import ModuleLevelDetails from 'views/pages/app/moduleDetails'
import SubModuleDetails from 'views/pages/app/submoduleDetails'
import TopicDetails from "views/pages/app/TopicDetails";
var routes = [
  {
    path: "/index",
    name: "Certificates",
    component: <Certification />,
    layout: "/admin",
    showcomponent:true
  },
  {
    path: "/feedback",
    name: "Quiz",
    component: <Feedback />,
    layout: "/admin",
    showcomponent:false

  },
  {
    path: "/quiz",
    name: "Quiz Mode",
    component: <Quiz />,
    layout: "/admin",
    showcomponent:false

  },
  // {
  //   path: "/resetPassword",
  //   name: "Reset Password",
  //   component: <Confirmpassword />,
  //   layout: "/admin",
  //   showcomponent:false
  // },
  // {
  //   path: "/category",
  //   name: "Quiz Mode",
  //   component: <Category />,
  //   layout: "/admin",
  //   showcomponent:true

  // },
  {
    path: "/certifications",
    name: "Quiz",
    component: <Certification />,
    layout: "/admin",
    showcomponent:false
  },
  {
    path: "/certifications/details",
    name: "Quiz",
    component: <CertificationDetail />,
    layout: "/admin",
    showcomponent:false

  },
  // {
  //   path: "/learning",
  //   name: "Learning Mode",
  //   component: <Learning />,
  //   layout: "/admin",
  //   showcomponent:true

  // },
  {
    path: "/learning/details",
    name: "Learning",
    component: <DetailLearning />,
    layout: "/admin",
    showcomponent:false

  },
  {
    path: "/learning/detailsmodule",
    name: "Learning",
    component: <DetailLearningModule />,
    layout: "/admin",
    showcomponent:false

  },
  // {
  //   path: "/learning/graph",
  //   name: "Learning Mode",
  //   component: <Graph />,
  //   layout: "/admin",
  //   showcomponent:false

  // },
  {
    path: "/tables",
    name: "Score",
    component: <Tables />,
    layout: "/admin",
    showcomponent:true

  },
  {
    path: "/user-profile",
    name: "User Profile",
    component: <Profile />,
    layout: "/admin",
    showcomponent:true

  },
  {
    path: "/user-details",
    name: "Certificate Details",
    component: <CertificateDetailsModule />,
    layout: "/admin",
    showcomponent:true

  },
  {
    path: "/user-modules-details",
    name: "Certificate Details",
    component: <ModuleLevelDetails />,
    layout: "/admin",
    showcomponent:false

  },{
    path: "/user-sub-modules-details",
    name: "Certificate Details",
    component: <SubModuleDetails />,
    layout: "/admin",
    showcomponent:false
  },
  {
    path: "/user-topic-details",
    name: "Certificate Details",
    component: < TopicDetails/>,
    layout: "/admin",
    showcomponent:false
  },

  {
    path: "/login",
    name: "Login",
    icon: "ni ni-key-25",
    component: <Login />,
    layout: "/auth",
    showcomponent:false
  },
  {
    path: "/forgot-password",
    name: "forgot Password",
    icon: "ni ni-key-25",
    component: <Forgetpass />,
    layout: "/auth",
    showcomponent:false
  },
  {
    path: "/recover-password",
    name: "confirm Password",
    icon: "ni ni-key-25",
    component: <Confirmpassword />,
    layout: "/auth",
    showcomponent:false
  },
  {
    path: "/register",
    name: "Register",
    icon: "ni ni-circle-08 ",
    component: <Register />,
    layout: "/auth",
    showcomponent:false

  },{
    path: "/payment",
    name: "Payment",
    icon: "ni ni-circle-08 ",
    component: <CardPage />,
    layout: "/admin",
    showcomponent:false

  }
];
export default routes;
//https://certify360-ehasl4rfha-uc.a.run.app/admin/payment